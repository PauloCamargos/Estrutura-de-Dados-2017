﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caGrafo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Criando objetos da classe Cidade
            Console.WriteLine("Testando o grafo");
            Cidade A = new Cidade("A", 1);
            Cidade B = new Cidade("B", 1);
            Cidade C = new Cidade("C", 1);
            Cidade D = new Cidade("D", 1);
            Cidade E = new Cidade("E", 1);

            
            //Lista que represetna o Grafo
            ListaGrafo lista = new ListaGrafo();

            //Inserindo nós no grafo, representando os objetos criados
            lista.insereFim(A);
            lista.insereFim(B);
            lista.insereFim(C);
            //lista.insereFim(D);
            //lista.insereFim(E);

            //Inserindo arestas entres os nos com respectiva distancia.
            lista.insereAresta(A, B, 1); // insereAresta(cidade_1, cidade_2, distancia);
            lista.insereAresta(A, C, 1);
            lista.insereAresta(B, C, 1);
            //lista.insereAresta(A, E, 1);
            //lista.insereAresta(B, E, 4);
            //lista.insereAresta(B, D, 5);
            //lista.insereAresta(C, E, 1);
            //lista.insereAresta(C, D, 2);
            //lista.insereAresta(D, E, 3);

            //lista.imprimeDireita();

            //lista.imprimeGrafo();
            lista.quantidadeDeNohs();
            lista.menorDistanciaEntre(A, C);
            //lista.excluiNoh(udi);


            //Criando uma aresta entre Uberlandia e Araguari
            // 1) Acessar a lista de adjacencia de Uberlandia (udi)
            //      1.1) Localizar o noh 'udi' no grafo
            //      1.2) Gettar a lista de adjacencia (ListaNohAdj)
            //      1.3) Executar: listaNohAdj.inserefim(ari)
            // 2) Repetir tudo para Araguari

            //NohListaGrafo nohUdi = lista.encontraNoh(udi);
            //(nohUdi.ListaAdj).InsereFim(ari);

            //NohListaGrafo nohAri = lista.encontraNoh(ari);
            //(nohAri.ListaAdj).InsereFim(udi);

            //// Criando uma aresta entre Uberaba e Uberlândia
            //NohListaGrafo nohUdi2 = lista.encontraNoh(udi);
            //(nohUdi2.ListaAdj).InsereFim(uba);

            //NohListaGrafo nohUba = lista.encontraNoh(uba);
            //(nohUba.ListaAdj).InsereFim(udi);

            Console.Read();
        }
    }
}
