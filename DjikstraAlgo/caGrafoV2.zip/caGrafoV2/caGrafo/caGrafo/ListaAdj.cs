﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caGrafo
{
    class ListaAdj
    {
        private NohListaAdjacente Inicio;
        private NohListaAdjacente Fim;
        private int qnt = 0;
        internal NohListaAdjacente INICIO { get => Inicio; set => Inicio = value; }
        internal NohListaAdjacente FIM { get => Fim; set => Fim = value; }

        public ListaAdj(NohListaAdjacente iNICIO, NohListaAdjacente fIM)
        {
            INICIO = iNICIO;
            FIM = fIM;
        }

        public ListaAdj()
        {
            INICIO = FIM = null;
        }

        public void InsereFim(Cidade elemento, double distancia)
        {
            qnt++;
            NohListaAdjacente novo = new NohListaAdjacente(elemento);
            novo.Peso = distancia;
            if (INICIO == null)
            {
                INICIO = FIM = novo;
            }
            else
            {
                FIM.Next = novo;
                novo.Previous = FIM;
                FIM = FIM.Next;
            }
        }

        internal void imprimeListaAdj()
        {
            NohListaAdjacente temp = INICIO;
            while (temp != null)
            {
                if (temp.Next != null)
                    Console.Write(temp.Data.Nome + " (" + temp.Peso + " Km)" + " - ");
                else
                    Console.Write(temp.Data.Nome + " (" + temp.Peso + " Km)");
                temp = temp.Next;
            }
            Console.WriteLine();

        }


        public NohListaAdjacente encontraNoh(Cidade elemento)
        {
            NohListaAdjacente temp = Inicio;
            while (temp != null)
            {
                if (temp.Data == elemento)
                {
                    return temp;
                }
                else
                {
                    temp = temp.Next;
                }
            }
            return temp;
        }

        public void ordenarLista()
        {
            NohListaAdjacente temp = this.Inicio;  // Variavel temporario do loop de fora
            NohListaAdjacente temp_2 = this.Inicio; // Variavel temporario do loop de dentro
            Cidade aux_data;
            double aux_distDijkstra;
            Cidade aux_caminhoDijkstra;
            bool naoEstaOrdenada = true;
            bool flag = true;
            while (naoEstaOrdenada)
            {
                while (temp_2 != null && flag)
                {
                    aux_data = temp_2.Data;
                    aux_distDijkstra = temp_2.distanciaDikstra;
                    aux_caminhoDijkstra = temp_2.caminhoDijkstra;

                    if (temp_2 == null || temp_2.Next == null)
                    {
                        naoEstaOrdenada = false;
                        flag = false;
                        break;
                    }

                    if (temp_2.Next.distanciaDikstra < temp_2.distanciaDikstra)
                    {

                        //Troca os nós de lugar
                        temp_2.Data = temp_2.Next.Data;
                        temp_2.distanciaDikstra = temp_2.Next.distanciaDikstra;
                        temp_2.caminhoDijkstra = temp_2.Next.caminhoDijkstra;

                        temp_2.Next.Data = aux_data;
                        temp_2.Next.distanciaDikstra = aux_distDijkstra;
                        temp_2.Next.caminhoDijkstra = aux_caminhoDijkstra;
                        temp_2 = this.INICIO;
                    }
                    else
                        temp_2 = temp_2.Next;
                    //Verfica se a lista está ordenada
                    while (temp != null)
                    {
                        if (temp == null || temp.Next == null)
                            break;
                        //temp.Next.distanciaDikstra > temp.distanciaDikstra ? naoEstaOrdenada = true : naoEstaOrdenada =false ;
                        if (temp.Next.distanciaDikstra > temp.distanciaDikstra)
                            naoEstaOrdenada = true;
                        else
                            naoEstaOrdenada = false;
                        temp = temp.Next;
                    }
                    temp = this.INICIO; ;
                }
            }

        }

        public void imprimeListaDjikstra()
        {
            NohListaAdjacente temp = INICIO;
            while (temp != null)
            {
                Console.Write(temp.Data.Nome + " (" + temp.distanciaDikstra + ",)"); + temp.caminhoDijkstra.+ ") -> ");
                temp = temp.Next;
            }
            Console.WriteLine();
        }

        public NohListaAdjacente encontrarEm(int posicao)
        {
            if (posicao <= 0)
            {
                Console.WriteLine("Posição inválida. Índices começam em 1.");
                return null;
            }
            else
            {
                if (this.Inicio == null)
                {
                    return null;
                }
                else
                {
                    NohListaAdjacente temp = Inicio;

                    if (posicao > qnt)
                        return null;
                    else
                    {
                        for (int i = 1; i < posicao; i++)
                            temp = temp.Next;
                        //Console.WriteLine("Elemento da posicao " + posicao + ": " + temp.Info);
                        return temp;
                    }
                }
            }
        }// Fim encontraEm( int posicao )
    }
}//fim da classe ListaAdj
