﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caGrafo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Criando objetos da classe Cidade
            //Console.WriteLine("Testando o grafo");
            Cidade araguari =       new Cidade("Araguari", 1);
            Cidade ituiutaba =      new Cidade("Ituiutaba", 1);
            Cidade centralina =     new Cidade("Centralina", 1);
            Cidade itumbiara =      new Cidade("Itumbiara", 1);
            Cidade capinopolis =    new Cidade("Capinópolis", 1);
            Cidade malegreminas =   new Cidade("Monte Alegre de Minas", 1);
            Cidade douradinhos =    new Cidade("Douradinhos", 1);
            Cidade tupaciguara =    new Cidade("Tupaciguara", 1);
            Cidade uberlandia =     new Cidade("Uberândia", 1);
            Cidade indianopolis =   new Cidade("Indianópolis", 1);
            Cidade novaPonte =      new Cidade("Nova Ponte", 1);
            Cidade romaria =        new Cidade("Romaria", 1);
            Cidade estrelaSul =     new Cidade("Estrela do Sul", 1);
            Cidade grupiara =       new Cidade("Grupiara", 1);
            Cidade cascalhoRico =   new Cidade("Cascalho Rico", 1);



            //grafo que represetna o Grafo
            ListaGrafo grafo = new ListaGrafo();

            //Inserindo nós no grafo, representando os objetos criados
            grafo.insereFim(araguari);
            grafo.insereFim(ituiutaba);
            grafo.insereFim(centralina);
            grafo.insereFim(itumbiara);
            grafo.insereFim(capinopolis);
            grafo.insereFim(malegreminas);
            grafo.insereFim(douradinhos);
            grafo.insereFim(tupaciguara);
            grafo.insereFim(uberlandia);
            grafo.insereFim(indianopolis);
            grafo.insereFim(novaPonte);
            grafo.insereFim(romaria);
            grafo.insereFim(estrelaSul);
            grafo.insereFim(grupiara);
            grafo.insereFim(cascalhoRico);

            grafo.insereAresta(capinopolis, centralina, 40);
            grafo.insereAresta(centralina, ituiutaba, 30);
            //Ituiutaba
            grafo.insereAresta(ituiutaba, malegreminas, 85);
            grafo.insereAresta(ituiutaba, douradinhos, 90);

            //Centralina
            grafo.insereAresta(centralina, itumbiara, 20);
            grafo.insereAresta(centralina, malegreminas, 75);

            //Itumbiara
            grafo.insereAresta(itumbiara, tupaciguara, 55);

            //Monte Alegre de Minas
            grafo.insereAresta(malegreminas, douradinhos, 28);
            grafo.insereAresta(malegreminas, uberlandia, 60);
            grafo.insereAresta(malegreminas, tupaciguara, 44);

            //Douradinhos
            grafo.insereAresta(douradinhos, uberlandia, 63);

            //Uberlândia
            grafo.insereAresta(uberlandia, araguari, 30);
            grafo.insereAresta(uberlandia, romaria, 78);
            grafo.insereAresta(uberlandia, indianopolis, 45);
            grafo.insereAresta(uberlandia, tupaciguara, 60);

            //Araguari
            grafo.insereAresta(araguari, cascalhoRico, 28);
            grafo.insereAresta(araguari, estrelaSul, 34);

            //Cascalho Rico
            grafo.insereAresta(cascalhoRico, grupiara, 32);

            //Grupiara
            grafo.insereAresta(grupiara, estrelaSul, 38);

            //Estrela do Sul
            grafo.insereAresta(estrelaSul, romaria, 27);

            //Romaria
            grafo.insereAresta(romaria, novaPonte, 28);

            //Nova Ponte
            grafo.insereAresta(novaPonte, indianopolis, 40);


            //grafo.imprimeDireita();

           // grafo.imprimeGrafo();
            //grafo.quantidadeDeNohs();
            grafo.menorDistanciaEntre(uberlandia, capinopolis);
            //grafo.excluiNoh(udi);


            Console.Read();
        }
    }
}
